// Package bitcask implements a high-performance key-value store based on a
// WAL and LSM.
package bitcask
