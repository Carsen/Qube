# Contributing

No preference. If you know how to use Github and have contributed to open source projects before then:

* File an issue
* Submit a pull request
* File an issue + Submit a pull request
* Use this project somewhere :)

Be sure to add yourself to the [AUTHORS](/AUTHORS) file when you submit your PR(s). Every contribution counts no how big or small!

Thanks for using Bitcask!
