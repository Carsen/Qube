// Package main is a simple command-line interface for reading/writing and performing operations on a Bitcask database
package main

func main() {
	Execute()
}
