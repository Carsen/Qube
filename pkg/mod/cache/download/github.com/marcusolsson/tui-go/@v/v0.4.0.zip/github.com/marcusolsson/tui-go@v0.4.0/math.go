package tui

// Maximum integer value for the current architecture.
const maxUint = ^uint(0)
const maxInt = int(maxUint >> 1)
