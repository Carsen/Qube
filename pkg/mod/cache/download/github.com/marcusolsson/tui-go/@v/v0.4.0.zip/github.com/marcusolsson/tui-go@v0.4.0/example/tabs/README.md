# tabs

Implementation of a more complex multi-view layout, however with visual tabs.

![Screenshot](screenshot.gif)
