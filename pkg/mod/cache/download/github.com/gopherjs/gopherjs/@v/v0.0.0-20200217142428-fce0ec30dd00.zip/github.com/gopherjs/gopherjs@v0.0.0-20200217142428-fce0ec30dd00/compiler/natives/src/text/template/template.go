// +build js

package template

const maxExecDepth = 3000
