// +build js,!linux

package syscall

const exitTrap = SYS_EXIT
