// +build js

package sync_test

import (
	"testing"
)

func TestPool(t *testing.T) {
	t.Skip()
}

func TestPoolGC(t *testing.T) {
	t.Skip()
}

func TestPoolRelease(t *testing.T) {
	t.Skip()
}

func TestCondCopy(t *testing.T) {
	t.Skip()
}
