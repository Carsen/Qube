To run the database:

./mkinfo -all

You can also generate a single entry:

./mkinfo -db <term>

